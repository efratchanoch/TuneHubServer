package com.example.tunehub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TuneHubApplication {

    public static void main(String[] args) {
        SpringApplication.run(TuneHubApplication.class, args);
    }

}
