package com.example.tunehub.service;

import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface TeacherMapper {
}
