package com.example.tunehub.dto;

public class UsersSignUpDTO {


    private String name;
    private String city;
    private String email;
    private String password;
    private String country;


}
