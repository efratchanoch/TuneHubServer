package com.example.tunehub.dto;

import org.springframework.web.multipart.MultipartFile;

public class PostMediaDTO {

    private Long id;
    private String type;  // AUDIO, VIDEO, IMAGE
    private String url;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
