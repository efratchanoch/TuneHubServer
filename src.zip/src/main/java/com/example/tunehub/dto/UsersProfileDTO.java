package com.example.tunehub.dto;

public class UsersProfileDTO {
}
