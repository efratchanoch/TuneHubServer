package com.example.tunehub.model;

public enum DifficultyLevel {
    EASY , MEDIUM , HARD
}
