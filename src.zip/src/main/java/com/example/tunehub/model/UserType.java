package com.example.tunehub.model;

public enum UserType {
    STUDENT , MANAGER , TEACHER, MUSIC_LOVER
}
